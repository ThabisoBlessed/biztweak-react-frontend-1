import React from 'react'

export const AdminStatistics = () => {
  return (
    <div>AdminStatistics</div>
  )
}
