import React from 'react'
import { AdminDashboard } from './AdminDashboard'

export const Admin = () => {
  return (
    <div className="w-full">
    <AdminDashboard />
  </div>
  )
}
