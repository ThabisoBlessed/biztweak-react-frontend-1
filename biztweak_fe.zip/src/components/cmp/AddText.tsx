import React from 'react'

export const AddText = () => {
  return (
    <div>AddText</div>
  )
}
