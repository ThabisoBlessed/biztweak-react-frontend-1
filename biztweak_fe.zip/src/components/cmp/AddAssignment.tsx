import React from 'react'

export const AddAssignment = () => {
  return (
    <div>AddAssignment</div>
  )
}
