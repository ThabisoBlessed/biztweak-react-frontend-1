import React from "react";
import { Dashboard } from "./Dashboard";
import "./LMS";

export const LMS = () => {
  return (
    <div className="w-full">
      <Dashboard />
    </div>
  );
};
