export interface IQuiz {
  answers: string;
  correctAnswer: boolean;
  id: number;
  question: string;
  status: string;
}
