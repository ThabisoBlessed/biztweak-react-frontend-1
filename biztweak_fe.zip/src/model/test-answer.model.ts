export interface ITestAnswer {
    id: number;
    answer: string;
    correct_answer: boolean;
}