export enum StatusCode {
    badRequest = 'ERR_BAD_REQUEST'
}