export enum EventFrequency {
    once = "once", 
    everyday = "everyday", 
    weekly = "weekly", 
    fortnight = "fortnight", 
    monthly = "monthly"
}