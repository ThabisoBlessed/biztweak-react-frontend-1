export enum UserRole {
    root = "ROOT"
}