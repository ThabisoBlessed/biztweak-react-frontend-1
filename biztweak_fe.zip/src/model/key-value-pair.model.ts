export interface KeyValuePair {
  key: object;
  value: object;
}
