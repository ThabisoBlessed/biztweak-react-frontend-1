export interface IBusinessIndustryAndPhase {
    businessPhase: any;
    businessIndustry: any;
}