/* eslint-disable new-cap */

export interface IAddress {
  apartment: string;
  streetNumber: number;
  streetName: string;
  city: string;
  province: string;
  postalCode: number;
}