/// <reference types="react-scripts" />
declare module "*.png" {
  export default "" as string;
}
declare module "*.svg" {
  export default "" as string;
}
declare module "*.jpeg" {
  export default "" as string;
}
declare module "*.jpg" {
  export default "" as string;
}
declare module "*.mp4" {
  export default "" as string;
}
declare module "*.mp3" {
  export default "" as string;
}